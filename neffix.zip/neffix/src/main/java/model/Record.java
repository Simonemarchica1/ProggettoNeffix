package model;

public class Record {
}
