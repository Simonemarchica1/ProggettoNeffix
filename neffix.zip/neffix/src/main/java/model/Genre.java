package model;

public class Genre {
}
