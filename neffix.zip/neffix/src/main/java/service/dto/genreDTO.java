package service.dto;

public class genreDTO {
}
