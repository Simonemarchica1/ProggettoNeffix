package service.dto;

public class userDTO {
}
