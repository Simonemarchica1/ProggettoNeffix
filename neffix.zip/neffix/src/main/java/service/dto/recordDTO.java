package service.dto;

public class recordDTO {
}
