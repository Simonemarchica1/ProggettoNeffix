package service;

public class adminService {
}
