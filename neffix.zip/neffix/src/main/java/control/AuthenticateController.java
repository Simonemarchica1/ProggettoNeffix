package control;

public class AuthenticateController {
}
