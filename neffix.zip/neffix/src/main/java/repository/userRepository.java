package repository;

public interface userRepository {
}
