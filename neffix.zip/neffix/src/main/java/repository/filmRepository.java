package repository;

public interface filmRepository {
}
