package repository;

public interface genreRepository {
}
