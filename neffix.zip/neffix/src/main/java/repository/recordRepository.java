package repository;

public interface recordRepository {
}
